import axios from "axios";
import { useEffect, useState } from "react";

export default function Home() {
  const [userId, setUserId] = useState("");
  const [list, setList] = useState([]);

  const getList = async () => {
    const res = await axios.get("/api/users");
    console.log(res.data);
    setList(res.data);
  };
  const goUpdate = async () => {
    const res = await axios.post("/api/users/editUser", { userId: userId });
    console.log(res.data);
  };

  const goSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post("/api/users/addUser", { userId: userId });
    console.log(res);
  };
  return (
    <div>
      <p>사용자목록</p>
      <form onSubmit={goSubmit}>
        <input type="text" onChange={(e) => setUserId(e.target.value)} />
        <button type="submit">add</button>
      </form>
      <button onClick={goUpdate}>버튼</button>
    </div>
  );
}
