const express = require("express");
const db = require("../../database");
const router = express.Router();

router.get("/", async (req, res) => {
  try {
    //행, 컬럼정보 반환
    const [rows, columns] = await db.query("select * from users");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "server error" });
  }
});
router.post("/addUser", async (req, res) => {
  const { userId } = req.body;

  const query = `INSERT INTO users (user_id, user_pw, user_name,create_date, modify_date)
                 VALUES(?, '123', '사용자테스트',now(),now())
                 `;
  const [result] = await db.query(query, [userId]);
  if (result.affectedRows > 0) {
    res.status(201).json({ success: true });
  } else {
    res.status(201).json({ success: false });
  }
});

//트랜잭션
router.post("/editUser", async (req, res) => {
  const { userId } = req.body;

  await db.transaction(async (conn) => {
    //1. insert 쿼리 날리기
    const query = `INSERT INTO users (user_id, user_pw, user_name,create_date, modify_date)
                   VALUES(?, '123', '사용자테스트',now(),now())
                  `;
    const result = await conn.query(query, [userId]);
    console.log(result);

    //2. update 쿼리 날리기
    const query2 = `UPDATE users
                    SET user_name = '테스트'
                    WHERE user_id = ?
                    `;
    const result2 = await conn.query(query, [userId]);
    console.log(result2);
  });
});

module.exports = router;
